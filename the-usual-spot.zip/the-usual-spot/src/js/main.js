// The Usual Spot - main.js
// This is the only JavaScript file. There is NO server, so everything is
// saved inside the browser using localStorage (users + posts) and
// sessionStorage (who is logged in - it clears when you close the tab).

// ---------------- saving and loading stuff ----------------
function getUsers() { return JSON.parse(localStorage.getItem("users") || "{}"); }
function saveUsers(users) { localStorage.setItem("users", JSON.stringify(users)); }
function getPosts() { return JSON.parse(localStorage.getItem("posts") || "[]"); }
function savePosts(posts) { localStorage.setItem("posts", JSON.stringify(posts)); }
function getLoggedIn() { return sessionStorage.getItem("loggedIn"); }

// Makes user text safe so nobody can sneak a <script> into a post
function safe(text) {
  var div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}

// Turns a password into scrambled text so we never store the real password.
// NOTE: this is a simple homemade scramble for the prototype. A real app
// would do this on a server with bcrypt or argon2.
function hashPassword(password) {
  var text = "hushline-salt" + password;
  var h = 0;
  for (var i = 0; i < text.length; i++) {
    h = (h * 31 + text.charCodeAt(i)) % 1000000007;
  }
  return String(h);
}

// Adds a few fake users/posts the first time so the feed is not empty
function addDemoData() {
  if (localStorage.getItem("users")) return;
  saveUsers({
    ada:   { handle: "ada",   name: "Ada L.", bio: "Writes about calm software.", joined: Date.now(), password: "" },
    marco: { handle: "marco", name: "Marco",  bio: "Photographer. Phone off at dinner.", joined: Date.now(), password: "" },
    luz:   { handle: "luz",   name: "Luz",    bio: "Reads privacy policies so you don't have to.", joined: Date.now(), password: "" }
  });
  savePosts([
    { id: "1", user: "luz",   text: "Reminder: if a free app wants your contacts, you are the product.", time: Date.now() - 3600000, likes: ["ada"] },
    { id: "2", user: "marco", text: "Posted a sunset today. No location tag, no problem.", time: Date.now() - 9000000, likes: [] },
    { id: "3", user: "ada",   text: "Welcome to The Usual Spot! Say what you think. Nobody is profiling you.", time: Date.now() - 20000000, likes: ["luz", "marco"] }
  ]);
}

// Adds the photo post one time (even for people who already visited before)
function addPhotoPost() {
  if (localStorage.getItem("photoAdded")) return;
  var posts = getPosts();
  posts.unshift({
    id: "photo1", user: "marco", time: Date.now() - 60000, likes: [],
    text: "Friday night at the usual spot.",
    image: "assets/img/party.jpg",
    alt: "Person in silver sunglasses and a white shirt in a crowded, red-lit room"
  });
  savePosts(posts);
  localStorage.setItem("photoAdded", "yes");
}

// ---------------- navbar + page protection ----------------
function setupNavbar() {
  var loggedIn = getLoggedIn();
  var guestLinks = document.querySelectorAll(".guest-only");
  var userLinks = document.querySelectorAll(".user-only");
  for (var i = 0; i < guestLinks.length; i++) guestLinks[i].style.display = loggedIn ? "none" : "inline";
  for (var j = 0; j < userLinks.length; j++) userLinks[j].style.display = loggedIn ? "inline" : "none";

  var logout = document.getElementById("logout");
  if (logout) logout.onclick = function () { sessionStorage.removeItem("loggedIn"); };
}

// Pages that need a login get sent to login.html. Login/signup get sent to the feed if you're already in.
function protectPage(page) {
  var loggedIn = getLoggedIn();
  if ((page == "feed" || page == "profile" || page == "privacy") && !loggedIn) {
    window.location.href = "login.html";
    return false;
  }
  if ((page == "login" || page == "signup") && loggedIn) {
    window.location.href = "feed.html";
    return false;
  }
  return true;
}

// ---------------- signup ----------------
function setupSignup() {
  document.getElementById("signupForm").onsubmit = function (e) {
    e.preventDefault();
    var handle = document.getElementById("handle").value.trim().toLowerCase();
    var name = document.getElementById("name").value.trim();
    var pw = document.getElementById("pw").value;
    var pw2 = document.getElementById("pw2").value;
    var error = document.getElementById("error");
    var users = getUsers();

    if (!/^[a-z0-9_]{3,20}$/.test(handle)) { error.textContent = "Username must be 3-20 letters, numbers or underscores."; return; }
    if (users[handle]) { error.textContent = "That username is already taken."; return; }
    if (pw.length < 8) { error.textContent = "Password must be at least 8 characters."; return; }
    if (pw != pw2) { error.textContent = "Passwords don't match."; return; }

    users[handle] = { handle: handle, name: name || handle, bio: "", joined: Date.now(), password: hashPassword(pw) };
    saveUsers(users);
    sessionStorage.setItem("loggedIn", handle);
    window.location.href = "feed.html";
  };
}

// ---------------- login ----------------
function setupLogin() {
  document.getElementById("loginForm").onsubmit = function (e) {
    e.preventDefault();
    var handle = document.getElementById("handle").value.trim().toLowerCase();
    var pw = document.getElementById("pw").value;
    var user = getUsers()[handle];

    // demo users have an empty password so they can't be logged into
    if (!user || user.password == "" || user.password != hashPassword(pw)) {
      document.getElementById("error").textContent = "Wrong username or password.";
      return;
    }
    sessionStorage.setItem("loggedIn", handle);
    window.location.href = "feed.html";
  };
}

// ---------------- feed ----------------
var feedFilter = "all"; // "all" or "mine"

// builds the html for one post
function postHtml(post, users, showButtons) {
  var author = users[post.user] || { handle: post.user, name: post.user };
  var me = getLoggedIn();
  var html = '<div class="card">';
  html += '<b><a href="profile.html?u=' + encodeURIComponent(author.handle) + '">' + safe(author.name) + '</a></b> ';
  html += '<span class="gray">@' + safe(author.handle) + ' - ' + new Date(post.time).toLocaleString() + '</span>';
  html += '<p>' + safe(post.text) + '</p>';
  // some posts have a photo (stored as a path inside the project)
  if (post.image) html += '<img class="post-image" src="../' + post.image + '" alt="' + safe(post.alt || "Photo") + '">';
  if (showButtons) {
    html += '<button class="small-btn" onclick="likePost(\'' + post.id + '\')">Like (' + post.likes.length + ')</button>';
    if (post.user == me) html += '<button class="small-btn" onclick="deletePost(\'' + post.id + '\')">Delete</button>';
  }
  return html + '</div>';
}

function showFeed() {
  var posts = getPosts();
  var users = getUsers();
  var html = "";
  for (var i = 0; i < posts.length; i++) {
    if (feedFilter == "mine" && posts[i].user != getLoggedIn()) continue;
    html += postHtml(posts[i], users, true);
  }
  if (html == "") html = '<div class="card gray">No posts yet. Write the first one!</div>';
  document.getElementById("postList").innerHTML = html;
}

function likePost(id) {
  var posts = getPosts();
  var me = getLoggedIn();
  for (var i = 0; i < posts.length; i++) {
    if (posts[i].id == id) {
      var spot = posts[i].likes.indexOf(me);
      if (spot == -1) posts[i].likes.push(me); else posts[i].likes.splice(spot, 1); // like / unlike
    }
  }
  savePosts(posts);
  showFeed();
}

function deletePost(id) {
  if (!confirm("Delete this post?")) return;
  var posts = getPosts().filter(function (p) { return p.id != id; });
  savePosts(posts);
  showFeed();
}

function setupFeed() {
  var box = document.getElementById("postText");
  var count = document.getElementById("count");
  box.oninput = function () { count.textContent = 280 - box.value.length; };

  document.getElementById("postBtn").onclick = function () {
    if (box.value.trim() == "") return;
    var posts = getPosts();
    posts.unshift({ id: String(Date.now()), user: getLoggedIn(), text: box.value.trim(), time: Date.now(), likes: [] });
    savePosts(posts);
    box.value = "";
    count.textContent = 280;
    showFeed();
  };
  document.getElementById("showAll").onclick = function () { feedFilter = "all"; showFeed(); };
  document.getElementById("showMine").onclick = function () { feedFilter = "mine"; showFeed(); };
  showFeed();
}

// ---------------- profile ----------------
function setupProfile() {
  var params = new URLSearchParams(window.location.search);
  var handle = params.get("u") || getLoggedIn(); // ?u=ada shows Ada's profile
  var users = getUsers();
  var user = users[handle];
  var box = document.getElementById("profileInfo");

  if (!user) { box.innerHTML = '<p>That user does not exist.</p>'; return; }

  var posts = getPosts().filter(function (p) { return p.user == handle; });
  box.innerHTML = "<h1>" + safe(user.name) + "</h1>" +
    '<p class="gray">@' + safe(user.handle) + " - joined " + new Date(user.joined).toLocaleDateString() + "</p>" +
    "<p>" + (user.bio ? safe(user.bio) : "No bio yet.") + "</p>" +
    "<p><b>" + posts.length + "</b> posts</p>";

  var html = "";
  for (var i = 0; i < posts.length; i++) html += postHtml(posts[i], users, false);
  document.getElementById("myPosts").innerHTML = html || '<p class="gray">No posts yet.</p>';

  // only show the edit form on your own profile
  var form = document.getElementById("editForm");
  if (handle != getLoggedIn()) { form.style.display = "none"; return; }
  document.getElementById("name").value = user.name;
  document.getElementById("bio").value = user.bio;
  form.onsubmit = function (e) {
    e.preventDefault();
    users[handle].name = document.getElementById("name").value.trim() || handle;
    users[handle].bio = document.getElementById("bio").value.trim();
    saveUsers(users);
    alert("Profile saved!");
    window.location.reload();
  };
}

// ---------------- privacy center ----------------
function setupPrivacy() {
  var me = getLoggedIn();
  var myPosts = getPosts().filter(function (p) { return p.user == me; });
  document.getElementById("info").innerHTML =
    "<p>Account: <b>@" + safe(me) + "</b></p>" +
    "<p>Your posts: <b>" + myPosts.length + "</b></p>" +
    "<p>Data sent to a server: <b>0 bytes</b></p>";

  document.getElementById("exportBtn").onclick = function () {
    var data = { profile: getUsers()[me], posts: myPosts };
    delete data.profile.password; // don't put the password in the file
    var link = document.createElement("a");
    link.href = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }));
    link.download = "my-usual-spot-data.json";
    link.click();
  };

  document.getElementById("deleteBtn").onclick = function () {
    if (!confirm("Delete your account and all your posts? You can't undo this.")) return;
    var users = getUsers();
    delete users[me];
    saveUsers(users);
    savePosts(getPosts().filter(function (p) { return p.user != me; }));
    sessionStorage.removeItem("loggedIn");
    window.location.href = "../index.html";
  };
}

// ---------------- start everything ----------------
var page = document.body.dataset.page; // each html page says which page it is
addDemoData();
addPhotoPost();
if (protectPage(page)) {
  setupNavbar();
  if (page == "signup") setupSignup();
  if (page == "login") setupLogin();
  if (page == "feed") setupFeed();
  if (page == "profile") setupProfile();
  if (page == "privacy") setupPrivacy();
}
